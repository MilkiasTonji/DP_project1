package com.example.milkias.adminmainactivity.Model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AddNewsDatabase extends SQLiteOpenHelper {
//    defining database
    private static final String DATABASE_NAME = "SalaryManagementSystem.db";
    private static final String TABLE_NAME = "addNewsTable";
    private static final int DATABASE_VERSION = 1;

//    defining the columns

    private final static String NEWS_ID = "NEWS_ID";
    private final static String NEWS_TITLE = "NEWS_TITLE";
    private final static String NEWS_DESC = "NEWS_DESC";





    public AddNewsDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(" CREATE TABLE " + TABLE_NAME + " (" +
                NEWS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NEWS_TITLE + " TEXT NOT NULL, " +
                NEWS_DESC + " TEXT NOT NULL);"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


//    inserting data to the database table

    public boolean insertData(AddNewsModel newsModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NEWS_TITLE, newsModel.getTitle());
        contentValues.put(NEWS_DESC, newsModel.getDescription());
        long result = db.insert(TABLE_NAME, null, contentValues);

        if (result == -1){
            return false;
        }else{
            return true;
        }

    }

//    fetch all the data
    public Cursor getAllNews(SQLiteDatabase database){
        database = this.getWritableDatabase();
        Cursor result = database.rawQuery("select * from " + TABLE_NAME, null);
        return result;
    }

    public Cursor fetchAllData(AddNewsModel model){
        SQLiteDatabase database = this.getWritableDatabase();
        String[] datas = {model.getTitle(), model.getDescription()};
        Cursor cursor = database.query(TABLE_NAME, datas, null, null,null, null, null);
        return cursor;
    }


}
