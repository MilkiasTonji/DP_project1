package com.example.milkias.adminmainactivity.Model;

public class AttendanceHistoryModel {
    String firstName;
    String lastName;
    String date;
    String attendance;

    public AttendanceHistoryModel(String firstName, String lastName, String date, String attendance) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.date = date;
        this.attendance = attendance;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }
}
