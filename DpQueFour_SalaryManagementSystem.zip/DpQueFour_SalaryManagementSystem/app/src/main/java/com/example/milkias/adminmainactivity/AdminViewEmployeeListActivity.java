package com.example.milkias.adminmainactivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import com.example.milkias.adminmainactivity.Adapters.EmployeeListAdapter;
import com.example.milkias.adminmainactivity.Adapters.NewAdapter;
import com.example.milkias.adminmainactivity.Model.AddNewsDatabase;
import com.example.milkias.adminmainactivity.Model.AddNewsModel;
import com.example.milkias.adminmainactivity.Model.EmployeeAttendanceDatabase;
import com.example.milkias.adminmainactivity.Model.User;
import com.example.milkias.adminmainactivity.Model.UserRegistrationDatabase;

import java.util.ArrayList;
import java.util.List;

public class AdminViewEmployeeListActivity extends AppCompatActivity {

    RecyclerView mRecyclerView;

    UserRegistrationDatabase registirationDatabase;
    private RecyclerView.Adapter mAdapter;
    private List<User> listUsers = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_employee_list);

        mRecyclerView = findViewById(R.id.list_of_users);

        registirationDatabase = new UserRegistrationDatabase(this);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


        Toolbar toolbar = findViewById(R.id.toolbar_employeelist);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getAllNewsFromDatabase();
    }



    public void getAllNewsFromDatabase(){
        SQLiteDatabase sqLiteDatabase = registirationDatabase.getReadableDatabase();
        Cursor cursor = registirationDatabase.getAllUsers(sqLiteDatabase);

        cursor.moveToFirst();

        do{
            User model = new User( null, cursor.getString(1), cursor.getString(2), null,null,null,null);
            listUsers.add(model);
        }while (cursor.moveToNext());
            registirationDatabase.close();

        mAdapter = new EmployeeListAdapter(listUsers, AdminViewEmployeeListActivity.this);
        mRecyclerView.setAdapter(mAdapter);
    }

}
