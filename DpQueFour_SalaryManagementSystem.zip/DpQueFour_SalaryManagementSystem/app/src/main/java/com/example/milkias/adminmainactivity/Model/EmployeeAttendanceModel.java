package com.example.milkias.adminmainactivity.Model;

public class EmployeeAttendanceModel {
    String name;
    boolean isAttended;
    int attended;

    public EmployeeAttendanceModel(String name, int attended) {
        this.name = name;
        this.attended = attended;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAttended() {
        return isAttended;
    }

    public void setAttended(boolean attended) {
        isAttended = attended;
    }

    public int getAttended() {
        return attended;
    }

    public void setAttended(int attended) {
        this.attended = attended;
    }
}
