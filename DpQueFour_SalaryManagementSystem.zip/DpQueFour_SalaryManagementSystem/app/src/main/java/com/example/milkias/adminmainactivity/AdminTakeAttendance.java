package com.example.milkias.adminmainactivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.milkias.adminmainactivity.Adapters.AttendanceHistoryAdapter;
import com.example.milkias.adminmainactivity.Adapters.NewAdapter;
import com.example.milkias.adminmainactivity.Model.AddNewsDatabase;
import com.example.milkias.adminmainactivity.Model.AddNewsModel;
import com.example.milkias.adminmainactivity.Model.AttendanceHistoryModel;
import com.example.milkias.adminmainactivity.Model.EmployeeAttendanceDatabase;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AdminTakeAttendance extends AppCompatActivity {

    FloatingActionButton fab_take_attendance_button;

    private AlertDialog.Builder builder;

    private Button submit_date;
    private TextView input_date;
    String job_date_selected;
    private DatePickerDialog.OnDateSetListener dateListener;

    AlertDialog dialog;
    RecyclerView mRecyclerView;

    EmployeeAttendanceDatabase mEmployeeAttendanceDatabase;


    private RecyclerView.Adapter mAdapter;
    private List<AttendanceHistoryModel> listNews = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_take_attendance);

        mRecyclerView = findViewById(R.id.attendance_history);
        fab_take_attendance_button = findViewById(R.id.fab_take_attendance_button);
        mEmployeeAttendanceDatabase = new EmployeeAttendanceDatabase(this);

        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        Toolbar toolbar = findViewById(R.id.toolbar_attendance);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        fab_take_attendance_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takeAttendance();
            }
        });

        displayAttendanceHistory();

    }

    private void takeAttendance() {
        builder = new AlertDialog.Builder(AdminTakeAttendance.this);
        final View mView = getLayoutInflater().inflate(R.layout.take_attendance_layout,null);


        submit_date = mView.findViewById(R.id.submit_date);
        input_date = mView.findViewById(R.id.input_date);

        input_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(
                        AdminTakeAttendance.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        dateListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();

            }
        });

        dateListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                input_date.setText(i + "/" + i1 + "/" + i2);
                job_date_selected = input_date.getText().toString();
            }
        };

//        clicking the next button
        submit_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent users_list = new Intent(AdminTakeAttendance.this, UsersAttendanceTaker.class);
                users_list.putExtra("attendance_date", job_date_selected);
                startActivity(users_list);
            }
        });


        builder.setView(mView);
        builder.setTitle("Take Attendance");
        dialog = builder.create();
        dialog.show();

    }

    public void displayAttendanceHistory(){
        SQLiteDatabase sqLiteDatabase = mEmployeeAttendanceDatabase.getReadableDatabase();
        Cursor cursor = mEmployeeAttendanceDatabase.getAllEmployeeList(sqLiteDatabase);

        cursor.moveToFirst();

        do{
            AttendanceHistoryModel model = new AttendanceHistoryModel(cursor.getString(0), cursor.getString(1), cursor.getString(2),cursor.getString(3));
            listNews.add(model);
        }while (cursor.moveToNext());
        mEmployeeAttendanceDatabase.close();
        mAdapter = new AttendanceHistoryAdapter(listNews, AdminTakeAttendance.this);
        mRecyclerView.setAdapter(mAdapter);
    }
}
