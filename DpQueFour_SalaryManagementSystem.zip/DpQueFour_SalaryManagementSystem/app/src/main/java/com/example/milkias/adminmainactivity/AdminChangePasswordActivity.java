package com.example.milkias.adminmainactivity;

import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.milkias.adminmainactivity.Model.UserRegistrationDatabase;

public class AdminChangePasswordActivity extends AppCompatActivity {

    UserRegistrationDatabase sqliteHelper;
    //Declaration EditTexts
    EditText firstname;
    EditText newpassword;
    EditText confirmpassword;
    String frstname,newpass,confirmpass;

    //Declaration TextInputLayout
    TextInputLayout textInputLayoutPassword;
    TextInputLayout layoutfirstname;
    TextInputLayout new_pwd;
    TextInputLayout confpwd;

    //Declaration Button
    Button reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_change_password);

        firstname = findViewById(R.id.firstname);
        newpassword = findViewById(R.id.editTextPassword);
        confirmpassword = findViewById(R.id.confirmpassword);
        textInputLayoutPassword = findViewById(R.id.textInputLayoutPasswordconfirm);
        layoutfirstname = findViewById(R.id.layoutfirstname);
        new_pwd  = findViewById(R.id.textInputLayoutPassword);
        confpwd = findViewById(R.id.textInputLayoutPasswordconfirm);
        reset = findViewById(R.id.buttonReset);


        Toolbar toolbar = findViewById(R.id.toolbar_change_password);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frstname = firstname.getText().toString().trim();
                newpass = newpassword.getText().toString().trim();
                confirmpass = confirmpassword.getText().toString().trim();
                if(frstname==null||"".equalsIgnoreCase(frstname)){
                    layoutfirstname.setError("first name is required!");

                }
                else if(newpass==null ||"".equalsIgnoreCase(newpass)){
                    new_pwd.setError("new password is required field");

                }
                else if(confirmpass==null ||"".equalsIgnoreCase(confirmpass)){
                    confpwd.setError("retype the above new password to check  the match");
                }
                else if(!newpass.equalsIgnoreCase(confirmpass)){
                    confpwd.setError("password doesn't match. re type!");
                }
                else{

                    sqliteHelper = new UserRegistrationDatabase(getApplicationContext());
                    sqliteHelper.updateEntry(newpass,frstname);
                    Snackbar.make(reset, "Successfully reset!", Snackbar.LENGTH_LONG).show();
                    firstname.setText("");
                    newpassword.setText("");
                    confirmpassword.setText("");

                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        sqliteHelper.close();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sqliteHelper.close();
    }
}
