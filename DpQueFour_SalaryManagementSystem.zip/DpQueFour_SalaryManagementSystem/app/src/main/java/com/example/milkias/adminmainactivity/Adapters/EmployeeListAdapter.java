package com.example.milkias.adminmainactivity.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.milkias.adminmainactivity.Model.AddNewsModel;
import com.example.milkias.adminmainactivity.Model.User;
import com.example.milkias.adminmainactivity.R;

import java.util.List;

public class EmployeeListAdapter extends RecyclerView.Adapter<EmployeeListAdapter.ViewHolder> {
    private List<User> newsLists;
    Context mContext;

    public EmployeeListAdapter(List<User> newsLists, Context context) {
        this.newsLists = newsLists;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.employee_single_layout,parent,false);
        return new EmployeeListAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User userModel = newsLists.get(position);
        String firstname = userModel.getFirst_name();
        String lastName = userModel.getLast_name();
        String username_one = firstname +" " + lastName;

        holder.username.setText(username_one);
        holder.role.setText("Manager of the company");
    }

    @Override
    public int getItemCount() {
        return newsLists.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView username, role;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            username = itemView.findViewById(R.id.username);
            role = itemView.findViewById(R.id.user_role);

        }
    }
}
