package com.example.milkias.adminmainactivity.Interfaces;

public interface Image {
    void displayImage();
}
