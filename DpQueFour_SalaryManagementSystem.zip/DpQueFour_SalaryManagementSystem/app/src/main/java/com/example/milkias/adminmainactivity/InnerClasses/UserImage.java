package com.example.milkias.adminmainactivity.InnerClasses;

import android.content.Context;
import android.widget.Toast;

import com.example.milkias.adminmainactivity.Interfaces.Image;

public class UserImage implements Image {

    private String filename;

    public UserImage(String filename){
        this.filename = filename;
        loadFromDisk(filename);
    }

    @Override
    public void displayImage() {
        System.out.println("Filename of the image" + filename);
    }

    public void loadFromDisk(String filename){
//        Toast something
        System.out.println("Filename of the image" + filename);
    }
}
