package com.example.milkias.adminmainactivity.Model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EmployeeAttendanceDatabase extends SQLiteOpenHelper {

    //    defining database
    private static final String DATABASE_NAME = "SalaryManagementSystemAttendance.db";
    private static final String TABLE_NAME = "attendanceTable";
    private static final int DATABASE_VERSION = 1;

//    defining the columns

    private final static String ATTENDANCE_ID = "ATTENDANCE_ID";
    private final static String EMPLOYEE_FIRST_NAME = "EMPLOYEE_FIRST_NAME";
    private final static String EMPLOYEE_LAST_NAME = "EMPLOYEE_LAST_NAME";
    private final static String ISATTENDED = "ISATTENDED";




    public EmployeeAttendanceDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(" CREATE TABLE " + TABLE_NAME + " (" +
                ATTENDANCE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EMPLOYEE_FIRST_NAME + " TEXT NOT NULL, " +
                EMPLOYEE_LAST_NAME + " TEXT NOT NULL, " +
                ISATTENDED + " INTEGER NOT NULL);"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


//    inserting data to the database table

    public boolean insertData(String firstName, String lastName, String date, String attendance){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EMPLOYEE_FIRST_NAME, firstName);
        contentValues.put(EMPLOYEE_LAST_NAME, lastName);
        contentValues.put(ISATTENDED, attendance);
        long result = db.insert(TABLE_NAME, null, contentValues);

        if (result == -1){
            return false;
        }else{
            return true;
        }

    }

    //    fetch all the data
    public Cursor getAllEmployeeList(SQLiteDatabase database){
       database = this.getWritableDatabase();
        Cursor result = database.rawQuery("select * from " + TABLE_NAME, null);
        return result;
    }


}
