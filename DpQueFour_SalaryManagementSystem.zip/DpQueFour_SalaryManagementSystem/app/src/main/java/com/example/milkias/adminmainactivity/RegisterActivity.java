package com.example.milkias.adminmainactivity;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.milkias.adminmainactivity.Model.User;
import com.example.milkias.adminmainactivity.Model.UserRegistrationDatabase;
import android.os.Handler;

public class RegisterActivity extends AppCompatActivity {

    EditText firstname;
    EditText lastname;
    EditText editTextEmail;
    EditText editTextPassword;
    EditText address;
    EditText gender;

    //Declaration TextInputLayout
    TextInputLayout layoutfirstname;
    TextInputLayout textInputLayoutUserlName;
    TextInputLayout textInputLayoutEmail;
    TextInputLayout textInputLayoutPassword;
    TextInputLayout  textInputLayoutGender;
    TextInputLayout textInputLayoutAddress;

    //Declaration Button
    Button buttonRegister,bypass_button;
    TextView textViewLogin;



    //Declaration SqliteHelper
    UserRegistrationDatabase sqliteHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        textViewLogin = findViewById(R.id.textViewLogin);
        bypass_button = findViewById(R.id.bypass_button);

        sqliteHelper = new UserRegistrationDatabase(this);
        initTextViewLogin();
        initViews();



        Toolbar toolbar = findViewById(R.id.toolbar_registration);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        bypass_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login_intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(login_intent);
            }
        });

        textViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login_intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(login_intent);
            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate()) {
                    String fname= firstname.getText().toString();
                    String lname = lastname.getText().toString();

                    String Email = editTextEmail.getText().toString();
                    String Password = editTextPassword.getText().toString();
                    String add = address.getText().toString();
                    String gen = gender.getText().toString();

                    //Check in the database is there any user associated with  this email
                    if (!sqliteHelper.isEmailExists(Email)) {

                        //Email does not exist now add new user to database
                        sqliteHelper.addUser(new User(null, fname,lname, Email, Password,add,gen));
                        Snackbar.make(buttonRegister, "User created successfully! Please Login ", Snackbar.LENGTH_LONG).show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                finish();
                            }
                        }, Snackbar.LENGTH_LONG);

                        Intent main_intent = new Intent(RegisterActivity.this, MainActivity.class);
                        startActivity(main_intent);
                    }else {

                        //Email exists with email input provided so show error user already exist
                        Snackbar.make(buttonRegister, "User already exists with same email ", Snackbar.LENGTH_LONG).show();
                    }


                }
            }
        });

    }


    //this method used to set Login TextView click event
    private void initTextViewLogin() {
        TextView textViewLogin = (TextView) findViewById(R.id.textViewLogin);
        textViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    //this method is used to connect XML views to its Objects
    private void initViews() {
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        firstname =  findViewById(R.id.firstname);
        lastname = findViewById(R.id.lastname);
        gender = findViewById(R.id.editTextGender) ;
        address = findViewById(R.id.editTextaddress);
        textInputLayoutEmail = findViewById(R.id.textInputLayoutEmail);
        textInputLayoutPassword = findViewById(R.id.textInputLayoutPassword);
        layoutfirstname = findViewById(R.id.layoutfirstname) ;
        textInputLayoutUserlName = findViewById(R.id.textInputLayoutUserlName);
        textInputLayoutAddress = findViewById(R.id.textInputLayoutAddress);
        textInputLayoutGender =findViewById(R.id.textInputLayoutGender);
        buttonRegister = findViewById(R.id.buttonRegister);

    }


    //This method is used to validate input given by user
    public boolean validate() {
        boolean valid = false;

        //Get values from EditText fields
        String fname = firstname.getText().toString();
        String lname = lastname.getText().toString();
        String Email = editTextEmail.getText().toString();
        String Password = editTextPassword.getText().toString();
        String addr = address.getText().toString();
        String gendr = gender.getText().toString();

        //Handling validation for UserName field
        if (fname.isEmpty()) {
            valid = false;
            layoutfirstname.setError("Please enter valid username!");
        } else {
            if (fname.length() > 3) {
                valid = true;
                layoutfirstname.setError(null);
            } else {
                valid = false;
                layoutfirstname.setError("User first name is to short!");
            }
        }
        if (lname.isEmpty()) {
            valid = false;
            layoutfirstname.setError("Please enter valid username!");
        } else {
            if (lname.length() > 3) {
                valid = true;
                textInputLayoutUserlName.setError(null);
            } else {
                valid = false;
                textInputLayoutUserlName.setError("User last name is to short!");
            }
        }

        //Handling validation for Email field
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            valid = false;
            textInputLayoutEmail.setError("Please enter valid email!");
        } else {
            valid = true;
            textInputLayoutEmail.setError(null);
        }

        //Handling validation for Password field
        if (Password.isEmpty()) {
            valid = false;
            textInputLayoutPassword.setError("Please enter valid password!");
        } else {
            if (Password.length() > 2) {
                valid = true;
                textInputLayoutPassword.setError(null);
            } else {
                valid = false;
                textInputLayoutPassword.setError("Password is to short!");
            }
        }

        return valid;
    }

}
