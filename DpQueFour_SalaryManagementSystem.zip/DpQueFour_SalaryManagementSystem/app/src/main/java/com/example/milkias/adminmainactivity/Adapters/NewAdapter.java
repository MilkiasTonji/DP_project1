package com.example.milkias.adminmainactivity.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.example.milkias.adminmainactivity.Model.AddNewsModel;
import com.example.milkias.adminmainactivity.R;

import java.util.ArrayList;
import java.util.List;

public class NewAdapter extends RecyclerView.Adapter<NewAdapter.ViewHolder>{

    private List<AddNewsModel> newsLists;
    Context mContext;


    public NewAdapter(List<AddNewsModel> newsListAdapter,Context context){
        newsLists = newsListAdapter;
        this.mContext = context;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_view_layout,parent,false);
        return new NewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        AddNewsModel newsModel = newsLists.get(position);

        holder.news_title_text.setText(newsModel.getTitle());
        holder.news_desc_text.setText(newsModel.getDescription());

    }

    @Override
    public int getItemCount() {
        return newsLists.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView news_title_text,news_desc_text;
        ViewHolder(View itemView) {
            super(itemView);
            news_title_text = itemView.findViewById(R.id.news_title_text);
            news_desc_text = itemView.findViewById(R.id.news_desc_text);
        }

    }
}
