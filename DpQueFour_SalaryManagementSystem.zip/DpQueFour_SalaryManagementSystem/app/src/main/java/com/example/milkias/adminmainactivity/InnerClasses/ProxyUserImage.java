package com.example.milkias.adminmainactivity.InnerClasses;

import com.example.milkias.adminmainactivity.Interfaces.Image;

public class ProxyUserImage implements Image {
    private UserImage mUserImage;
    private String filename;

    public ProxyUserImage(String filename){
        this.filename = filename;
    }

    @Override
    public void displayImage() {
        if (mUserImage == null){
            mUserImage = new UserImage(filename);
        }
        mUserImage.displayImage();
    }
}
