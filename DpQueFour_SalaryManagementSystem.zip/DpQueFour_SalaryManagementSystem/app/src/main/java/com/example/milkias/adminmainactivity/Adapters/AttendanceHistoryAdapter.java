package com.example.milkias.adminmainactivity.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.milkias.adminmainactivity.Model.AttendanceHistoryModel;
import com.example.milkias.adminmainactivity.Model.User;
import com.example.milkias.adminmainactivity.R;

import java.util.List;

public class AttendanceHistoryAdapter extends RecyclerView.Adapter<AttendanceHistoryAdapter.ViewHolder> {

    private List<AttendanceHistoryModel> attendanceList;
    Context mContext;

    public AttendanceHistoryAdapter(List<AttendanceHistoryModel> newsLists, Context context) {
        this.attendanceList = newsLists;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.attendance_history_layout,parent,false);
        return new AttendanceHistoryAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AttendanceHistoryModel model = attendanceList.get(position);
        String firstName = model.getFirstName();
        String lastName = model.getLastName();
        String username =  firstName + " " + lastName;

        holder.employeeName.setText(username);
        holder.attendance.setText(model.getAttendance());
        holder.date.setText(model.getDate());
    }

    @Override
    public int getItemCount() {
        return attendanceList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView date, employeeName,attendance;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            employeeName = itemView.findViewById(R.id.employee_name_history);
            date = itemView.findViewById(R.id.attendance_date);
            attendance = itemView.findViewById(R.id.is_attended);
        }
    }
}
