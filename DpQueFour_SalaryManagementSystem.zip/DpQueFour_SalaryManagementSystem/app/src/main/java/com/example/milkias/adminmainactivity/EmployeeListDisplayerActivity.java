package com.example.milkias.adminmainactivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.Toast;

import com.example.milkias.adminmainactivity.Adapters.TakeAttendanceAdapter;
import com.example.milkias.adminmainactivity.Model.EmployeeAttendanceDatabase;
import com.example.milkias.adminmainactivity.Model.User;
import com.example.milkias.adminmainactivity.Model.UserRegistrationDatabase;

import java.util.ArrayList;
import java.util.List;

public class EmployeeListDisplayerActivity extends AppCompatActivity {

    RecyclerView mRecyclerView;

    UserRegistrationDatabase registrationDatabase;
    EmployeeAttendanceDatabase mEmployeeAttendanceDatabase;
    private RecyclerView.Adapter mAdapter;
    private List<User> listEmployees = new ArrayList<>();

    Button save_attendance_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_list_displayer);


        mRecyclerView = findViewById(R.id.attend_list_recyclerView);
        registrationDatabase = new UserRegistrationDatabase(this);
        mEmployeeAttendanceDatabase = new EmployeeAttendanceDatabase(this);

//        save_attendance_button = findViewById(R.id.save_attendance_button);

//
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


        Toolbar toolbar = findViewById(R.id.toolbar_employee_list_attendance);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


//        call the method
        getAllNewsFromDatabase();

//        save_attendance_button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                saveAttendanceToDatabase();
//            }
//        });

    }

    private void saveAttendanceToDatabase() {
        String firstName = getIntent().getStringExtra("firstName");
        String lastName = getIntent().getStringExtra("lastName");
        String date = getIntent().getStringExtra("attendance_date");
        String attendance = getIntent().getStringExtra("attendance");

        boolean isInserted = mEmployeeAttendanceDatabase.insertData(firstName, lastName, date, attendance);
        if (isInserted){
            Toast.makeText(EmployeeListDisplayerActivity.this, "Attendance is saved successfully!", Toast.LENGTH_SHORT).show();
            Intent attendance_intent_main = new Intent(EmployeeListDisplayerActivity.this, AdminTakeAttendance.class);
            startActivity(attendance_intent_main);
        }else {
            Toast.makeText(EmployeeListDisplayerActivity.this, "Something went wrong please try again", Toast.LENGTH_SHORT).show();
        }
    }

//    fetching the data from the database

    public void getAllNewsFromDatabase(){
        SQLiteDatabase sqLiteDatabase = registrationDatabase.getReadableDatabase();
        Cursor cursor = registrationDatabase.getAllUsers(sqLiteDatabase);

        cursor.moveToFirst();

        do{
            User model = new User( null, cursor.getString(1), cursor.getString(2), null,null,null,null);
            listEmployees.add(model);
        }while (cursor.moveToNext());
            registrationDatabase.close();

        mAdapter = new TakeAttendanceAdapter(listEmployees, EmployeeListDisplayerActivity.this);
        mRecyclerView.setAdapter(mAdapter);
    }



}
