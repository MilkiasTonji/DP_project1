package com.example.milkias.adminmainactivity.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.milkias.adminmainactivity.EmployeeListDisplayerActivity;
import com.example.milkias.adminmainactivity.Model.User;
import com.example.milkias.adminmainactivity.R;

import java.util.List;

public class TakeAttendanceAdapter extends RecyclerView.Adapter<TakeAttendanceAdapter.ViewHolder>{


    private List<User> employeeList;
    Context mContext;
    String attended;


    public TakeAttendanceAdapter(List<User> attendances,Context context){
        employeeList = attendances;
        this.mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.attendance_employee_list_layout,parent,false);
        return new TakeAttendanceAdapter.ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {

        User userModel = employeeList.get(position);
        final String firstname = userModel.getFirst_name();
        final String lastName = userModel.getLast_name();
        String username_one = firstname +" " + lastName;
         holder.employee_name.setText(username_one);


//                 holder.checkbox.setChecked(true);
                 if (holder.checkbox.isChecked()){
                     attended = "PRESENT";
                 }else{
                     attended = "ABSENT";
                 }
                 Intent attendance_intent = new Intent(mContext, EmployeeListDisplayerActivity.class);
                 attendance_intent.putExtra("firstName",firstname);
                 attendance_intent.putExtra("lastName",lastName);
                 attendance_intent.putExtra("attendance",attended);
                 mContext.startActivity(attendance_intent);


    }

    @Override
    public int getItemCount() {
        return employeeList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView employee_name;
        LinearLayout linear_parent;
        CheckBox checkbox;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            employee_name = itemView.findViewById(R.id.employee_name);
            checkbox = itemView.findViewById(R.id.checkbox);
            linear_parent = itemView.findViewById(R.id.linear_parent);

        }
    }
}
