package com.example.milkias.adminmainactivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.milkias.adminmainactivity.Adapters.EmployeeAttendance;
import com.example.milkias.adminmainactivity.Adapters.EmployeeListAdapter;
import com.example.milkias.adminmainactivity.Adapters.TakeAttendanceAdapter;
import com.example.milkias.adminmainactivity.Model.EmployeeAttendanceDatabase;
import com.example.milkias.adminmainactivity.Model.User;
import com.example.milkias.adminmainactivity.Model.UserRegistrationDatabase;

import java.util.ArrayList;
import java.util.List;

public class UsersAttendanceTaker extends AppCompatActivity {

    private RecyclerView user_attendance_taker_recyclerView;

    UserRegistrationDatabase registirationDatabase;
    private RecyclerView.Adapter mAdapter;
    private List<User> listUsers = new ArrayList<>();
    EmployeeAttendanceDatabase mEmployeeAttendanceDatabase;

    Button save_attendance_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_attendance_taker);

        user_attendance_taker_recyclerView = findViewById(R.id.user_attendance_taker_recyclerView);


        registirationDatabase = new UserRegistrationDatabase(this);
        mEmployeeAttendanceDatabase = new EmployeeAttendanceDatabase(this);

        save_attendance_button = findViewById(R.id.save_attendance_button);

        user_attendance_taker_recyclerView.setHasFixedSize(true);
        user_attendance_taker_recyclerView.setLayoutManager(new LinearLayoutManager(this));


        Toolbar toolbar = findViewById(R.id.toolbar_user_attendace_taker);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getAllEmployeeList();

        save_attendance_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveAttendanceToDatabase();
            }
        });

    }

    private void saveAttendanceToDatabase() {
//        String firstName = getIntent().getStringExtra("firstName");
//        String lastName = getIntent().getStringExtra("lastName");
//        String date = getIntent().getStringExtra("attendance_date");
//        String attendance = getIntent().getStringExtra("attendance");

        boolean isInserted = mEmployeeAttendanceDatabase.insertData("Milkias", "Tonji", "15/12/04", "attended");
        if (isInserted){
            Toast.makeText(UsersAttendanceTaker.this, "Attendance is saved successfully!", Toast.LENGTH_SHORT).show();
            Intent attendance_intent_main = new Intent(UsersAttendanceTaker.this, AdminTakeAttendance.class);
            startActivity(attendance_intent_main);
        }else {
            Toast.makeText(UsersAttendanceTaker.this, "Something went wrong please try again", Toast.LENGTH_SHORT).show();
        }
    }

    public void getAllEmployeeList(){
        SQLiteDatabase sqLiteDatabase = registirationDatabase.getReadableDatabase();
        Cursor cursor = registirationDatabase.getAllUsers(sqLiteDatabase);

        cursor.moveToFirst();

        do{
            User model = new User( null, cursor.getString(1), cursor.getString(2), null,null,null,null);
            listUsers.add(model);
        }while (cursor.moveToNext());
        registirationDatabase.close();

        mAdapter = new EmployeeAttendance(listUsers, UsersAttendanceTaker.this);
        user_attendance_taker_recyclerView.setAdapter(mAdapter);

    }

}
